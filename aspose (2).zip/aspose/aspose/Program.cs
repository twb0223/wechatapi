﻿using Aspose.Words;
using Aspose.Words.Tables;
using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aspose
{
    class Program
    {
        static void Main(string[] args)
        {
            Aspose.Words.Document doc = new Aspose.Words.Document("a.doc");
            Aspose.Words.DocumentBuilder builder = new Aspose.Words.DocumentBuilder(doc);


            builder.StartTable();
          

            #region title
            for (int i = 0; i < 8; i++)
            {
                builder.InsertCell();
                builder.CellFormat.Borders.LineStyle = LineStyle.None;
                builder.CellFormat.Borders.Top.LineStyle = LineStyle.Single;
                builder.CellFormat.Borders.Bottom.LineStyle = LineStyle.Single;
                builder.CellFormat.HorizontalMerge = CellMerge.None;
                builder.ParagraphFormat.LineSpacingRule = LineSpacingRule.Multiple;
                builder.ParagraphFormat.LineSpacing = 15.3;
                builder.CellFormat.Width = 90;
                builder.Write(i + "");
            }
            builder.EndRow();
            #endregion

            for (int k = 0; k < 2; k++)
            {
                builder.InsertCell();
                builder.CellFormat.Borders.LineStyle = LineStyle.None;
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;
                builder.CellFormat.HorizontalMerge = CellMerge.First;
                builder.Write("groupName1111111111111111111111111111111111" + k);
                for (int i = 0; i < 7; i++)
                {

                    builder.InsertCell();
                    builder.CellFormat.Borders.LineStyle = LineStyle.None;
                    builder.CellFormat.HorizontalMerge = CellMerge.Previous;
                }
                builder.EndRow();

                for (int l = 0; l < 2; l++)
                {
                    builder.InsertCell();
                   builder.CellFormat.Borders.LineStyle = LineStyle.None;
                    builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;
                    builder.Font.Underline = Underline.Single;
                    builder.ParagraphFormat.LineSpacingRule = LineSpacingRule.Multiple;
                    builder.ParagraphFormat.LineSpacing = 12;
                    builder.CellFormat.HorizontalMerge = CellMerge.First;
                    builder.Write("childname2222222222222222222222222222222"+l);
                    for (int i = 0; i < 7; i++)
                    {
                        builder.InsertCell();
                        builder.ParagraphFormat.LineSpacingRule = LineSpacingRule.Multiple;
                        builder.ParagraphFormat.LineSpacing = 12;
                        builder.CellFormat.Borders.LineStyle = LineStyle.None;
                        builder.CellFormat.HorizontalMerge = CellMerge.Previous;
                    }
                    builder.EndRow();

                    for (int j = 0; j < 2; j++)
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            builder.InsertCell();
                            builder.CellFormat.HorizontalMerge = CellMerge.None;
                            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;
                            builder.Font.Underline = Underline.None;
                            builder.ParagraphFormat.LineSpacingRule = LineSpacingRule.Multiple;
                            builder.ParagraphFormat.LineSpacing = 12;
                            builder.Write(i + "col");
                        }
                        builder.EndRow();
                    }

                    builder.InsertCell();
                    builder.CellFormat.Borders.LineStyle = LineStyle.None;
                    builder.ParagraphFormat.LineSpacingRule = LineSpacingRule.Multiple;
                    builder.ParagraphFormat.LineSpacing = 12;
                    builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;
                    builder.CellFormat.HorizontalMerge = CellMerge.First;
                    for (int i = 0; i < 7; i++)
                    {
                                                builder.InsertCell();
                        builder.CellFormat.Borders.LineStyle = LineStyle.None;
                        builder.ParagraphFormat.LineSpacingRule = LineSpacingRule.Multiple;
                        builder.ParagraphFormat.LineSpacing = 12;
                        builder.CellFormat.HorizontalMerge = CellMerge.Previous;
                    }
                    builder.EndRow();


                }
            }
            builder.EndTable();
           
            doc.Save("a.doc");
            WordToPDF("E:\\Code\\aspose\\aspose\\bin\\Debug\\a.doc", "E:\\Code\\aspose\\aspose\\bin\\Debug\\a.pdf");
        }

        public static bool WordToPDF(string sourcePath, string targetPath)
        {
            bool result = false;
            Microsoft.Office.Interop.Word.Application application = new Microsoft.Office.Interop.Word.Application();
            Microsoft.Office.Interop.Word.Document document = null;
            try
            {
                application.Visible = false;
                document = application.Documents.Open(sourcePath);
                document.ExportAsFixedFormat(targetPath, WdExportFormat.wdExportFormatPDF);
                result = true;
            }
            catch (Exception e)
            {
                result = false;
            }
            finally
            {
                document.Close();
            }
            return result;
        }
      
    }
}
